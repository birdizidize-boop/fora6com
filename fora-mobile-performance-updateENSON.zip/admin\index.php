<?php
$appRoot = is_dir(dirname(__DIR__) . '/app') ? dirname(__DIR__) : dirname(__DIR__, 2);
require $appRoot . '/app/bootstrap.php';
require_admin();

$sections = [
    'sponsors' => ['Sponsorlar', 'Sponsor markaları ve yönlendirmeleri'],
    'bonuses' => ['Bonuslar', 'Deneme ve diğer bonus kampanyaları'],
    'slider_banners' => ['Slider & Banner', 'Konumlu görsel/video ve gömülü bağlantılar'],
    'content_blocks' => ['İçerik & Vitrin', 'Sayfa metinleri ve vitrin alanları'],
    'users' => ['Kullanıcılar', 'Hesap durumu ve FORA Coin bakiyeleri'],
];
$section = $_GET['section'] ?? 'sponsors';
if (!isset($sections[$section])) $section = 'sponsors';
$pdo = db();
$flash = '';
$columns = [];
$editable = [];
$rows = [];
$sponsorOptions = [];
if ($pdo) try {
    $sponsorOptions = $pdo->query("SELECT id,name FROM sponsors ORDER BY name")->fetchAll();
} catch (Throwable $e) {}

$labels = [
    'name'=>'Ad','slug'=>'Kısa ad','logo_url'=>'Logo URL','banner_url'=>'Banner URL',
    'description'=>'Açıklama','bonus_text'=>'Bonus metni','category'=>'Kategori',
    'target_url'=>'Tıklama bağlantısı','visibility'=>'Yayında','featured'=>'Öne çıkar',
    'sponsor_tier'=>'Sponsor seviyesi','sort_order'=>'Sıra','sponsor_id'=>'Sponsor ID',
    'title'=>'Başlık','image_url'=>'Görsel URL','excerpt'=>'Kısa açıklama',
    'content'=>'Detay içerik ve maddeli şartlar','starts_at'=>'Başlangıç','ends_at'=>'Bitiş',
    'category_label'=>'Kategori etiketi','cta_text'=>'CTA metni','badge_text'=>'Rozet',
    'placement'=>'Konum','media_type'=>'Medya türü','media_url'=>'Medya URL',
    'mobile_media_url'=>'Mobil medya URL','link_url'=>'Gömülü bağlantı',
    'link_label'=>'Bağlantı etiketi','open_new_tab'=>'Yeni sekmede aç',
    'autoplay_seconds'=>'Geçiş süresi (sn)','status'=>'Durum','role'=>'Rol',
    'points'=>'FORA Coin','area'=>'Alan','subtitle'=>'Alt başlık','body'=>'İçerik',
];
$selects = [
    'visibility'=>['1'=>'Yayında','0'=>'Gizli'],
    'featured'=>['1'=>'Evet','0'=>'Hayır'],
    'open_new_tab'=>['1'=>'Evet','0'=>'Hayır'],
    'media_type'=>['image'=>'Görsel','video'=>'Video'],
    'placement'=>[
        'top'=>'Üst orta (tam genişlik)','left'=>'Sol dikey','right'=>'Sağ dikey',
        'middle'=>'Orta içerik','bottom'=>'Alt orta (tam genişlik)'
    ],
    'sponsor_tier'=>['main'=>'Ana sponsor','trusted'=>'Güvenilir','standard'=>'Standart'],
    'role'=>['member'=>'Üye','editor'=>'Editör','admin'=>'Yönetici'],
    'status'=>['active'=>'Aktif','suspended'=>'Askıda','pending'=>'Bekliyor'],
];

if ($pdo) {
    try {
        $columns = $pdo->query("DESCRIBE `$section`")->fetchAll();
        $editable = array_values(array_filter(array_column($columns, 'Field'),
            fn($c) => !in_array($c, ['id','created_at','updated_at','password_hash'], true)));
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            check_csrf();
            $action = $_POST['action'] ?? '';
            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($section === 'users' && $id === (int)$_SESSION['uid']) {
                    $flash = 'Kendi yönetici hesabınızı silemezsiniz.';
                } elseif ($section === 'sponsors') {
                    $q = $pdo->prepare('SELECT COUNT(*) FROM bonuses WHERE sponsor_id=?');
                    $q->execute([$id]);
                    if ((int)$q->fetchColumn() > 0) {
                        $flash = 'Bu sponsora bağlı bonuslar var. Önce bonusları silin veya başka sponsora taşıyın.';
                    } else {
                        $q = $pdo->prepare('DELETE FROM sponsors WHERE id=?');
                        $q->execute([$id]);
                        $flash = 'Sponsor silindi.';
                    }
                } else {
                    $q = $pdo->prepare("DELETE FROM `$section` WHERE id=?");
                    $q->execute([$id]);
                    $flash = 'Kayıt silindi.';
                }
            } elseif ($action === 'save') {
                $id = (int)($_POST['id'] ?? 0);
                $data = [];
                foreach ($editable as $c) {
                    if (array_key_exists($c, $_POST)) $data[$c] = $_POST[$c] === '' ? null : $_POST[$c];
                }
                if ($section === 'users') $data = array_intersect_key($data, array_flip(['role','status','points']));
                if ($section === 'bonuses') {
                    $sponsorId = (int)($data['sponsor_id'] ?? 0);
                    $exists = $pdo->prepare('SELECT COUNT(*) FROM sponsors WHERE id=?');
                    $exists->execute([$sponsorId]);
                    if (!$sponsorId || !(int)$exists->fetchColumn()) throw new RuntimeException('Geçerli sponsor seçilmedi.');
                    foreach (['target_url','image_url'] as $urlField) {
                        $url = trim((string)($data[$urlField] ?? ''));
                        if ($url !== '' && !filter_var($url, FILTER_VALIDATE_URL) && !str_starts_with($url, '/uploads/')) {
                            throw new RuntimeException('Güvenli bağlantı biçimi gerekli.');
                        }
                        if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL) && !in_array(strtolower((string)parse_url($url, PHP_URL_SCHEME)), ['http','https'], true)) {
                            throw new RuntimeException('Yalnızca HTTP/HTTPS bağlantıları kabul edilir.');
                        }
                    }
                    $data['cta_text'] = trim((string)($data['cta_text'] ?? '')) ?: 'Bonusu Al';
                }
                if ($data) {
                    if ($id) {
                        $set = implode(',', array_map(fn($c) => "`$c`=?", array_keys($data)));
                        $q = $pdo->prepare("UPDATE `$section` SET $set WHERE id=?");
                        $q->execute([...array_values($data), $id]);
                    } else {
                        $names = implode(',', array_map(fn($c) => "`$c`", array_keys($data)));
                        $marks = implode(',', array_fill(0, count($data), '?'));
                        $q = $pdo->prepare("INSERT INTO `$section` ($names) VALUES ($marks)");
                        $q->execute(array_values($data));
                    }
                    $flash = 'Kayıt kaydedildi.';
                }
            }
        }
        $rows = $pdo->query("SELECT * FROM `$section` ORDER BY " .
            (in_array('sort_order', array_column($columns,'Field'), true) ? 'sort_order,id DESC' : 'id DESC') .
            " LIMIT 250")->fetchAll();
    } catch (Throwable $e) {
        $flash = $section === 'slider_banners'
            ? 'Slider tablosu henüz kurulmamış. database/admin-media-layout.sql dosyasını bir kez içe aktarın.'
            : ($e instanceof RuntimeException ? $e->getMessage() : 'İşlem tamamlanamadı. Zorunlu alanları ve veri biçimini kontrol edin.');
    }
}
$editId = (int)($_GET['edit'] ?? 0);
$editing = null;
if ($editId > 0 && $pdo) {
    $q = $pdo->prepare("SELECT * FROM `$section` WHERE id=?");
    $q->execute([$editId]);
    $editing = $q->fetch();
}
function field_input(string $name, string $value, array $selects, array $labels, array $sponsorOptions=[]): void {
    $label = $labels[$name] ?? ucwords(str_replace('_',' ',$name));
    echo '<label><span>'.e($label).'</span>';
    if ($name === 'sponsor_id') {
        echo '<select name="sponsor_id" required><option value="">Sponsor seçin</option>';
        foreach ($sponsorOptions as $s) echo '<option value="'.intval($s['id']).'" '.($value===(string)$s['id']?'selected':'').'>'.e($s['name']).'</option>';
        echo '</select>';
    } elseif (isset($selects[$name])) {
        echo '<select name="'.e($name).'">';
        foreach ($selects[$name] as $k=>$v) echo '<option value="'.e((string)$k).'" '.($value===(string)$k?'selected':'').'>'.e($v).'</option>';
        echo '</select>';
    } elseif ($name === 'category') {
        echo '<input name="category" list="bonus-categories" value="'.e($value).'" required><datalist id="bonus-categories"><option value="Deneme"><option value="Hoş Geldin"><option value="Kayıp"><option value="Diğer"></datalist>';
    } elseif (preg_match('/description|content|body|excerpt|subtitle/i',$name)) {
        echo '<textarea name="'.e($name).'" rows="4">'.e($value).'</textarea>';
    } elseif (preg_match('/_at$/',$name)) {
        echo '<input type="datetime-local" name="'.e($name).'" value="'.e(str_replace(' ','T',substr($value,0,16))).'">';
    } else {
        echo '<input name="'.e($name).'" value="'.e($value).'" '.(preg_match('/url/',$name)?'inputmode="url"':'').'>';
    }
    echo '</label>';
}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FORA Yönetim</title><link rel="stylesheet" href="/assets/app.css?v=6"></head>
<body class="admin-body"><div class="admin-shell">
<header class="admin-top"><div><span class="eyebrow">FORA YÖNETİM</span><h1>Kontrol Merkezi</h1><p>İçerik, kampanya ve kullanıcı yönetimi</p></div><a class="ghost" href="/">Siteyi görüntüle ↗</a></header>
<?php if($flash):?><div class="notice"><?=e($flash)?></div><?php endif?>
<nav class="admin-nav" aria-label="Yönetim bölümleri">
<?php foreach($sections as $k=>$meta):?><a class="<?=$k===$section?'active':''?>" href="?section=<?=$k?>"><b><?=$meta[0]?></b><small><?=$meta[1]?></small></a><?php endforeach?>
<a href="/admin/media.php"><b>Medya Kütüphanesi</b><small>PNG, JPEG, WebP ve ölçüler</small></a>
<a href="/admin/settings.php"><b>Site Ayarları</b><small>Görünüm ve Coin sistemi</small></a>
</nav>
<main class="admin-main">
<div class="admin-section-head"><div><span class="eyebrow">YÖNETİM</span><h2><?=$sections[$section][0]?></h2><p><?=$sections[$section][1]?></p></div><a class="btn" href="?section=<?=$section?>&edit=-1">+ Yeni kayıt</a></div>
<?php if(isset($_GET['edit']) && $columns):?>
<form method="post" class="admin-form"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=intval($editing['id']??0)?>">
<?php foreach($editable as $c): if($section==='users'&&!in_array($c,['role','status','points'],true))continue; field_input($c,(string)($editing[$c]??''),$selects,$labels,$sponsorOptions); endforeach?>
<div class="admin-form-actions"><button class="btn">Kaydet</button><a class="ghost" href="?section=<?=$section?>">Vazgeç</a></div></form>
<?php endif?>
<?php if($section==='bonuses'):?><div class="admin-hint"><b>Public Bonuslar sayfası önizleme</b><span>Kaydedilen aktif kampanyalar sponsor bilgileriyle birlikte doğrudan public sayfada görünür.</span><a class="ghost" href="/?page=bonuses" target="_blank" rel="noopener">Bonuslar sayfasını aç ↗</a></div><?php endif?>
<?php if(!$rows):?><div class="admin-empty">Henüz kayıt yok. “Yeni kayıt” ile ekleyebilirsiniz.</div>
<?php else:?><div class="admin-records"><?php foreach($rows as $r):?>
<article class="admin-record"><div class="admin-record-title"><b><?=e((string)($r['title']??$r['name']??$r['username']??('#'.$r['id'])))?></b><span>#<?=intval($r['id'])?></span></div>
<dl><?php foreach($r as $c=>$v): if(in_array($c,['id','password_hash'],true))continue;?><div><dt><?=e($labels[$c]??$c)?></dt><dd><?=e(mb_strimwidth((string)$v,0,150,'…','UTF-8'))?></dd></div><?php endforeach?></dl>
<div class="admin-record-actions"><a class="ghost" href="?section=<?=$section?>&edit=<?=intval($r['id'])?>">Düzenle</a><form method="post" onsubmit="return confirm('Bu kayıt silinsin mi?')"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=intval($r['id'])?>"><button class="ghost danger">Sil</button></form></div></article>
<?php endforeach?></div><?php endif?>
</main></div></body></html>
