SET NAMES utf8mb4;

ALTER TABLE bonuses
  MODIFY category VARCHAR(80) NOT NULL,
  MODIFY target_url VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS category_label VARCHAR(80) NULL AFTER category,
  ADD COLUMN IF NOT EXISTS cta_text VARCHAR(80) NOT NULL DEFAULT 'Bonusu Al' AFTER target_url,
  ADD COLUMN IF NOT EXISTS badge_text VARCHAR(80) NULL AFTER cta_text;

DROP PROCEDURE IF EXISTS fora_bonus_fk_restrict;
DELIMITER //
CREATE PROCEDURE fora_bonus_fk_restrict()
BEGIN
  DECLARE fk_name VARCHAR(128);
  SELECT CONSTRAINT_NAME INTO fk_name
  FROM information_schema.KEY_COLUMN_USAGE
  WHERE TABLE_SCHEMA=DATABASE()
    AND TABLE_NAME='bonuses'
    AND COLUMN_NAME='sponsor_id'
    AND REFERENCED_TABLE_NAME='sponsors'
  LIMIT 1;

  IF fk_name IS NOT NULL THEN
    SET @drop_fk=CONCAT('ALTER TABLE bonuses DROP FOREIGN KEY `',REPLACE(fk_name,'`','``'),'`');
    PREPARE stmt FROM @drop_fk;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;

  ALTER TABLE bonuses
    ADD CONSTRAINT fk_bonus_sponsor_restrict
    FOREIGN KEY(sponsor_id) REFERENCES sponsors(id)
    ON UPDATE CASCADE ON DELETE RESTRICT;
END//
DELIMITER ;
CALL fora_bonus_fk_restrict();
DROP PROCEDURE fora_bonus_fk_restrict;
