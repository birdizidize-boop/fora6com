SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS slider_banners (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(190) NOT NULL,
 placement ENUM('top','left','right','middle','bottom') NOT NULL DEFAULT 'top',
 media_type ENUM('image','video') NOT NULL DEFAULT 'image',
 media_url VARCHAR(500) NOT NULL,
 mobile_media_url VARCHAR(500) NULL,
 link_url VARCHAR(500) NULL,
 link_label VARCHAR(120) NULL,
 open_new_tab TINYINT(1) NOT NULL DEFAULT 1,
 visibility TINYINT(1) NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 100,
 autoplay_seconds SMALLINT UNSIGNED NOT NULL DEFAULT 6,
 starts_at DATETIME NULL,
 ends_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NULL,
 INDEX(placement,visibility,sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
