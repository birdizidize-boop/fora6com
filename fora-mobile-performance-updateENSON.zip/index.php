<?php
$appRoot = is_dir(__DIR__ . '/app') ? __DIR__ : dirname(__DIR__);
require $appRoot . '/app/bootstrap.php';
$requestHost = strtolower((string)preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
$trafficHosts = $config['traffic']['redirect_hosts'] ?? ['gir.fora6.com'];
$primaryHost = strtolower((string)(parse_url((string)($config['app_url'] ?? 'https://fora6.com'), PHP_URL_HOST) ?: 'fora6.com'));
$isTrafficHost = in_array($requestHost, $trafficHosts, true);
if (!$isTrafficHost && $requestHost !== $primaryHost && $requestHost !== 'www.' . $primaryHost) {
    $pdo = db();
    if ($pdo) {
        try {
            $hostQ = $pdo->prepare("SELECT COUNT(*) FROM traffic_domains WHERE hostname=? AND status='active'");
            $hostQ->execute([$requestHost]);
            $isTrafficHost = (int)$hostQ->fetchColumn() > 0;
        } catch (Throwable $e) {
        }
    }
}
if ($isTrafficHost) {
    require $appRoot . '/app/traffic.php';
    require $appRoot . '/app/traffic_redirect.php';
    exit;
}
$page = preg_replace('/[^a-z-]/', '', $_GET['page'] ?? 'home');
$allowed = ['home','sponsors','sponsor-search','bonuses','chat','leaderboard','login','register','forgot','legal'];
if (!in_array($page, $allowed, true)) { http_response_code(404); $page='home'; }
$needsSponsors = in_array($page, ['home','sponsors','sponsor-search'], true);
$sponsors = $needsSponsors ? array_values(array_filter(json_rows('sponsors'), static fn(array $row): bool => (int)($row['visibility'] ?? 0) === 1)) : [];
$featuredSponsors = array_values(array_filter($sponsors, static fn(array $row): bool => (int)($row['featured'] ?? 0) === 1));
if (!$featuredSponsors) $featuredSponsors = array_slice($sponsors, 0, 8);
$bonuses = [];
$sliderBanners = [];
if ($page === 'bonuses' && db()) try {
    $bonuses = db()->query("SELECT b.*,s.name sponsor_name,s.logo_url sponsor_logo_url,s.target_url sponsor_target_url
        FROM bonuses b JOIN sponsors s ON s.id=b.sponsor_id
        WHERE b.visibility=1 AND s.visibility=1
          AND (b.starts_at IS NULL OR b.starts_at<=NOW())
          AND (b.ends_at IS NULL OR b.ends_at>=NOW())
        ORDER BY b.featured DESC,b.sort_order,b.id DESC")->fetchAll();
} catch (Throwable $e) {}
if (db()) try {
    $sliderBanners = db()->query("SELECT * FROM slider_banners WHERE visibility=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) ORDER BY placement,sort_order,id DESC")->fetchAll();
} catch (Throwable $e) {}
$coinBalance=current_coin_balance();
$heroTitle=site_setting('hero_title','Güvenilir markalar ve teknoloji tek merkezde.');
$heroText=site_setting('hero_text','FORA ekosistemindeki sponsorları ve dijital markaları tek ekrandan keşfedin.');
$accentColor=site_setting('accent_color','#a8ff00');
$telegramBotUsername=trim(site_setting('telegram_bot_username',''));
$leaders=[];
if($page==='leaderboard' && db())try{$leaders=db()->query("SELECT username,points FROM users WHERE status='active' ORDER BY points DESC,id ASC LIMIT 100")->fetchAll();}catch(Throwable $e){}
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';
    if (!rate_limit($action ?: 'form')) $message = 'Çok hızlı işlem yaptınız. Lütfen biraz bekleyin.';
    elseif ($action === 'login') {
        $pdo=db(); $u=trim((string)($_POST['identity']??'')); $p=(string)($_POST['password']??'');
        $row=$pdo ? $pdo->prepare('SELECT * FROM users WHERE (email=? OR username=?) AND status="active" LIMIT 1') : null;
        if ($row) { $row->execute([$u,$u]); $user=$row->fetch(); }
        if (!empty($user) && password_verify($p,$user['password_hash'])) {
            session_regenerate_id(true); $_SESSION['uid']=$user['id']; $_SESSION['role']=$user['role']; $_SESSION['name']=$user['username'];
            redirect_local(($_POST['next']??'') ?: '/');
        }
        $message='Bilgiler eşleşmedi veya hesap aktif değil.';
    } elseif ($action === 'register') {
        $pdo=db(); $username=trim((string)($_POST['username']??'')); $email=trim((string)($_POST['email']??'')); $pass=(string)($_POST['password']??'');
        if (!$pdo) $message='Kayıt için veritabanı kurulumu gereklidir.';
        elseif (!preg_match('/^[a-zA-Z0-9_]{3,24}$/',$username) || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($pass)<10) $message='Bilgileri ve en az 10 karakterli şifreyi kontrol edin.';
        else try {$q=$pdo->prepare('INSERT INTO users(username,email,password_hash,role,status,created_at) VALUES(?,?,?,"member","active",NOW())');$q->execute([$username,$email,password_hash($pass,PASSWORD_DEFAULT)]);$message='Hesabınız oluşturuldu. Şimdi giriş yapabilirsiniz.';}catch(Throwable $e){$message='Kullanıcı adı veya e-posta kullanımda.';}
    }
}
function nav_active(string $p): string { global $page; return $page===$p?'active':''; }
?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="FORA dijital ekosistem portalı: sponsorlar, topluluk ve FORA Coin.">
<title>FORA — Dijital Ekosistem Portalı</title><style>:root{--green:<?=e($accentColor)?>}</style>
<link rel="stylesheet" href="/assets/app.css?v=7">
</head><body>
<a class="skip" href="#content">İçeriğe geç</a>
<header class="top"><button class="menu-btn" aria-label="Menüyü aç" aria-expanded="false">☰</button><a class="brand" href="/"><img src="/assets/brands/optimized/fora-logo-light-sm.png" width="320" height="320" alt="FORA"><small>DİJİTAL MERKEZ</small></a><label class="top-search"><span>⌕</span><input type="search" placeholder="Sponsor veya içerik ara…" aria-label="Genel arama"></label><div class="top-actions"><?php if(!empty($_SESSION['uid'])):?><a class="points" href="/?page=leaderboard">◆ <?=coin_format($coinBalance)?> FORA Coin</a><?php endif?><button class="lang" type="button">TR</button><?php if(empty($_SESSION['uid'])):?><a class="login-link" href="/?page=login">Giriş Yap</a><a class="btn" href="/?page=register">Kayıt Ol</a><?php else:?><span>Merhaba, <?=e($_SESSION['name'])?></span><?php endif?></div></header>
<div class="quickbar"><a class="telegram-pulse" href="<?=e($telegramBotUsername!==''?'https://t.me/'.$telegramBotUsername:'/?page=chat')?>" rel="noopener">⚡ Telegram topluluğumuza katıl</a><a href="/?page=sponsor-search" aria-label="Sponsor ara">⌕ Sponsor Ara</a><a href="/?page=leaderboard" aria-label="FORA Coin">◆ Coin</a></div>
<aside class="sidebar"><nav aria-label="Ana menü"><a class="<?=nav_active('home')?>" href="/">⌂ <span>Ana Sayfa</span></a><a class="<?=nav_active('sponsors')?>" href="/?page=sponsors">◇ <span>Sponsorlar</span></a><a class="<?=nav_active('bonuses')?>" href="/?page=bonuses">✦ <span>Bonuslar</span></a><a class="<?=nav_active('chat')?>" href="/?page=chat">◉ <span>FORA Sohbet</span></a><a class="<?=nav_active('leaderboard')?>" href="/?page=leaderboard">♛ <span>Liderlik</span></a><a class="<?=nav_active('legal')?>" href="/?page=legal">ⓘ <span>Yasal</span></a></nav><div class="ecosystem"><small>FORA EKOSİSTEMİ</small><b>FORAGRAMM</b><b>TGM</b><b>foragraph</b><b>Birmilyoncu</b><b>Fırsat Vitrini</b></div></aside>
<main id="content">
<?php if($message):?><div class="notice" role="status"><?=e($message)?></div><?php endif?>
<?php
$bannerGroups=[];
foreach($sliderBanners as $banner)$bannerGroups[$banner['placement']][]=$banner;
$renderBanners=static function(array $items,string $placement):void{
    if(!$items)return;
    echo '<section class="banner-zone banner-zone-'.e($placement).'" data-slider>';
    foreach($items as $i=>$b){
        $href=trim((string)($b['link_url']??''));
        echo '<article class="site-banner'.($i===0?' active':'').'">';
        if($href!=='')echo '<a href="'.e($href).'"'.((int)($b['open_new_tab']??1)?' target="_blank" rel="noopener noreferrer sponsored"':'').'>';
        if(($b['media_type']??'image')==='video')echo '<video muted loop playsinline preload="none" data-src="'.e((string)$b['media_url']).'"></video>';
        else{echo '<picture>';if(!empty($b['mobile_media_url']))echo '<source media="(max-width:700px)" srcset="'.e((string)$b['mobile_media_url']).'">';echo '<img src="'.e((string)$b['media_url']).'" alt="'.e((string)$b['title']).'" loading="lazy"></picture>';}
        if(!empty($b['link_label']))echo '<span>'.e((string)$b['link_label']).'</span>';
        if($href!=='')echo '</a>';
        echo '</article>';
    }
    echo '</section>';
};
$renderBanners($bannerGroups['top']??[],'top');
$renderBanners($bannerGroups['left']??[],'left');
$renderBanners($bannerGroups['right']??[],'right');
$renderBanners($bannerGroups['middle']??[],'middle');
?>
<?php if($page==='home'):?>
<section class="mobile-quick-actions reveal" aria-label="Hızlı işlemler"><a href="/?page=sponsor-search"><span class="quick-icon">⌕</span><small>KEŞFET</small><b>Sponsor Ara</b><em>Markayı hızlı bul</em></a><a href="/?page=leaderboard"><span class="quick-icon">◆</span><small>FORA COIN</small><b>Coinlerim</b><em>Sıralamayı görüntüle</em></a><a href="/?page=chat"><span class="quick-icon">◉</span><small>TOPLULUK</small><b>Sohbete Katıl</b><em>Üyelerle konuş</em></a></section>
<section class="hero reveal"><div><span class="eyebrow">FORA DİJİTAL EKOSİSTEMİ</span><h1><?=e($heroTitle)?></h1><p><?=e($heroText)?></p><div class="hero-actions"><a class="btn" href="/?page=sponsors">Sponsorları Keşfet</a><a class="ghost" href="/?page=chat">FORA Sohbete Katıl</a></div></div><div class="network"><img class="hero-brand-image" src="/assets/brands/optimized/fora-logo-dark-sm.png" width="480" height="480" alt="FORA ana marka logosu" decoding="async"></div></section>
<?php if($featuredSponsors):?><section class="mobile-sponsor-bubbles reveal"><div class="section-kicker">ÖNE ÇIKANLAR</div><div class="bubble-track"><?php foreach($featuredSponsors as $s):?><a href="/?page=sponsors#s<?=intval($s['id'])?>"><span><?php if(!empty($s['logo_url'])):?><img src="<?=e((string)$s['logo_url'])?>" alt="" loading="lazy" decoding="async"><?php else:?><?=e(mb_substr((string)$s['name'],0,1,'UTF-8'))?><?php endif?></span><b><?=e((string)$s['name'])?></b></a><?php endforeach?></div></section>
<section class="strip reveal"><span>ÖNE ÇIKAN SPONSORLAR</span><?php foreach($featuredSponsors as $s):?><a href="/?page=sponsors#s<?=intval($s['id'])?>"><i style="--c:#a8ff00"><?=e(mb_substr((string)$s['name'],0,1,'UTF-8'))?></i><?=e((string)$s['name'])?><small><?=e((string)($s['bonus_text'] ?? ''))?></small></a><?php endforeach?></section><?php endif?>
<section class="mobile-service-grid reveal" aria-label="FORA bölümleri"><a href="/?page=sponsors"><span>◇</span><b>Sponsorlar</b></a><a href="/?page=bonuses"><span>✦</span><b>Bonuslar</b></a><a href="/?page=chat"><span>◉</span><b>Sohbet</b></a><a href="/?page=leaderboard"><span>♛</span><b>Liderlik</b></a><a href="/?page=sponsor-search"><span>⌕</span><b>Sponsor Ara</b></a><a href="/?page=legal"><span>ⓘ</span><b>Yasal</b></a><a href="/?page=login"><span>◎</span><b>Hesabım</b></a><a href="#fora-markalari"><span>⌁</span><b>FORA Ağı</b></a></section>
<section class="reveal"><div class="section-head"><div><span class="eyebrow">FORA AĞI</span><h2>Dijital ekosistem</h2></div></div><div class="feature-grid"><article class="feature big"><span>FORA</span><h3>Markalar tek merkezde</h3><p>Sponsorları ve FORA bünyesindeki dijital hizmetleri güvenli, hızlı ve düzenli bir arayüzden keşfedin.</p><a href="/?page=sponsors">Sponsorları görüntüle →</a></article><article class="feature"><span>FORAGRAMM</span><h3>Merkezi yayın ve dağıtım ağı</h3><p>FORA ekosistemindeki içerik akışının kalbi.</p></article><article class="feature"><span>FORAGRAPH</span><h3>Dijital görünürlük</h3><p>Markaların dijital erişimini güçlendiren teknoloji ağı.</p></article></div></section>
<section id="fora-markalari" class="reveal"><div class="section-head"><div><span class="eyebrow">MARKALARIMIZ</span><h2>FORA ekosistemi</h2></div></div><div class="brand-grid"><article><img src="/assets/brands/optimized/foragramm-dark-sm.png" width="480" height="320" loading="lazy" decoding="async" alt="FORAGRAMM"><b>Merkezi yayın ve dağıtım</b></article><article><img src="/assets/brands/optimized/foragraph-dark-sm.png" width="480" height="320" loading="lazy" decoding="async" alt="foragraph"><b>Dijital görünürlük</b></article><article><img src="/assets/brands/optimized/birmilyoncu-sm.png" width="420" height="420" loading="lazy" decoding="async" alt="Birmilyoncu"><b>Topluluk ve etkileşim</b></article><article><img src="/assets/brands/optimized/birmilyoncu-sohbet-sm.png" width="420" height="420" loading="lazy" decoding="async" alt="Birmilyoncu Sohbet"><b>Sohbet topluluğu</b></article><article><img src="/assets/brands/optimized/luckygramm-sm.png" width="420" height="420" loading="lazy" decoding="async" alt="LuckyGramm"><b>FORA ekosistem markası</b></article></div></section>
<?php elseif(in_array($page,['sponsors','sponsor-search'],true)):?>
<section class="page-hero"><span class="eyebrow">FORA SPONSOR AĞI</span><h1>Güvenilir sponsorları keşfet</h1><p>Aktif sponsorları inceleyin ve resmi yönlendirme bağlantıları üzerinden güvenle ziyaret edin.</p><input id="sponsorSearch" class="big-search" type="search" placeholder="Sponsor adı veya kategori yazın…" autofocus></section><div class="result-line"><b id="resultCount"><?=count($sponsors)?></b> sponsor listeleniyor</div>
<?php if(!$sponsors):?><div class="notice">Sponsor listesi şu anda güncelleniyor. Lütfen kısa süre sonra tekrar kontrol edin.</div><?php else:?>
<?php $sponsorGroups=['main'=>['Ana Sponsorlar',array_values(array_filter($sponsors,fn($s)=>($s['sponsor_tier']??'standard')==='main'))],'trusted'=>['Güvenilir Sponsorlar',array_values(array_filter($sponsors,fn($s)=>($s['sponsor_tier']??'standard')==='trusted'))],'standard'=>['Diğer Sponsorlar',array_values(array_filter($sponsors,fn($s)=>!in_array(($s['sponsor_tier']??'standard'),['main','trusted'],true)))]];?>
<?php foreach($sponsorGroups as $tier=>$group):if(!$group[1])continue;?><section class="sponsor-group sponsor-group-<?=$tier?>"><div class="section-head"><h2><?=$group[0]?></h2></div><div class="sponsor-grid"><?php foreach($group[1] as $s):?><article class="sponsor-card" id="s<?=intval($s['id'])?>" data-search="<?=e(mb_strtolower((string)$s['name'].' '.(string)$s['category'],'UTF-8'))?>"><div class="sponsor-logo" style="--c:#a8ff00"><?php if(!empty($s['logo_url'])):?><img src="<?=e((string)$s['logo_url'])?>" alt="<?=e((string)$s['name'])?>" loading="lazy" decoding="async"><?php else:?><?=e(mb_substr((string)$s['name'],0,1,'UTF-8'))?><?php endif?></div><div><small><?=e((string)$s['category'])?></small><h2><?=e((string)$s['name'])?></h2><p><?=e((string)$s['description'])?></p><b><?=e((string)($s['bonus_text'] ?? ''))?></b></div><a class="btn safe-out" href="<?=e((string)$s['target_url'])?>" target="_blank" rel="noopener noreferrer sponsored">Siteye Git ↗</a></article><?php endforeach?></div></section><?php endforeach?>
<?php endif?>
<?php elseif($page==='bonuses'):?>
<section class="page-title"><span class="eyebrow">FORA BONUS MERKEZİ</span><h1>Bonuslar</h1><p>Deneme, hoş geldin ve kayıp bonuslarını tek ekranda inceleyin.</p></section>
<?php $bonusCategories=array_values(array_unique(array_filter(array_map(static fn($b)=>(string)($b['category']??''),$bonuses))));?>
<div class="tabs bonus-tabs" role="tablist"><button class="active" data-bonus-filter="all">Tüm Bonuslar</button><?php foreach($bonusCategories as $category):?><button data-bonus-filter="<?=e($category)?>"><?=e($category==='Deneme'?'Deneme Bonusları':$category)?></button><?php endforeach?></div>
<?php if(!$bonuses):?><div class="notice">Bonus içerikleri hazırlanıyor.</div><?php else:?><section class="bonus-grid"><?php foreach($bonuses as $b):?>
<?php $bonusImage=(string)(($b['image_url']??'')?:($b['sponsor_logo_url']??''));$bonusTargetRaw=(string)(($b['target_url']??'')?:($b['sponsor_target_url']??''));$bonusTarget=(filter_var($bonusTargetRaw,FILTER_VALIDATE_URL)&&in_array(strtolower((string)parse_url($bonusTargetRaw,PHP_URL_SCHEME)),['http','https'],true))?$bonusTargetRaw:'#';$bonusCategory=(string)(($b['category_label']??'')?:($b['category']??''));?>
<article class="bonus-card" data-bonus-category="<?=e((string)$b['category'])?>"><div class="bonus-media"><?php if($bonusImage!==''):?><img src="<?=e($bonusImage)?>" alt="<?=e((string)$b['title'])?>" loading="lazy"><?php else:?><span>FORA</span><?php endif?></div><div><?php if(!empty($b['badge_text'])):?><b class="bonus-badge"><?=e((string)$b['badge_text'])?></b><?php endif?><small><?=e($bonusCategory)?> • <?=e((string)$b['sponsor_name'])?></small><h2><?=e((string)$b['title'])?></h2><p><?=e((string)$b['excerpt'])?></p><div class="card-actions"><button class="ghost bonus-detail" type="button" data-title="<?=e((string)$b['title'])?>" data-content="<?=e((string)$b['content'])?>" data-image="<?=e($bonusImage)?>">Detaylar</button><a class="btn" href="<?=e($bonusTarget)?>" target="_blank" rel="noopener noreferrer sponsored"><?=e((string)(($b['cta_text']??'')?:'Bonusu Al'))?></a></div></div></article>
<?php endforeach?></section><dialog id="bonusDialog"><button class="modal-close" aria-label="Kapat">×</button><div class="modal-art"></div><h2></h2><div class="modal-copy"></div></dialog><?php endif?>
<?php elseif($page==='chat'):?>
<section class="page-title"><span class="eyebrow">FORA TOPLULUK</span><h1>FORA Sohbet</h1><p>Yalnız kayıtlı üyeler mesaj gönderebilir. Her geçerli mesaj 0,10 FORA Coin; 10 mesaj 1 FORA Coin kazandırır.</p></section><section class="chat-shell"><div class="chat-head"><b>Topluluk sohbeti</b><span>◆ <?=coin_format($coinBalance)?> FORA Coin</span></div><div id="chatMessages" class="chat-messages" aria-live="polite"></div><?php if(empty($_SESSION['uid'])):?><div class="notice">Mesaj göndermek için önce <a href="/?page=login&next=/?page=chat">giriş yapın veya kaydolun</a>.</div><?php else:?><form id="chatForm" class="chat-form"><input type="hidden" name="csrf" value="<?=csrf()?>"><input name="message" maxlength="500" minlength="3" placeholder="Mesajınızı yazın…" required autocomplete="off"><button class="btn">Gönder</button></form><small id="chatStatus">Spam, tekrar ve çok kısa mesajlar Coin kazandırmaz.</small><?php endif?></section>
<?php elseif($page==='leaderboard'):?>
<section class="page-title"><span class="eyebrow">FORA COIN</span><h1>Liderlik</h1><p>Topluluk üyelerinin FORA Coin sıralaması. 10 geçerli mesaj = 1 FORA Coin.</p></section><section class="leaderboard"><?php if(!$leaders):?><div class="notice">Liderlik listesi henüz oluşmadı.</div><?php else:?><ol><?php foreach($leaders as $i=>$leader):?><li><strong>#<?=$i+1?> <?=e($leader['username'])?></strong><span>◆ <?=coin_format($leader['points'])?> FORA Coin</span></li><?php endforeach?></ol><?php endif?></section>
<?php elseif(in_array($page,['login','register','forgot'],true)):?>
<section class="auth-shell"><div class="auth-promo"><span class="eyebrow">FORA HESAP</span><h1>Ekosisteme katıl.</h1><p>Hesabınızı ve FORA hizmetlerini tek profilden yönetin.</p><div class="mini-network">FORA</div></div><div class="auth-card"><?php if($page==='login'):?><h2>Tekrar hoş geldin</h2><p>Hesabınıza güvenli giriş yapın.</p><?php if($telegramBotUsername!==''):?><a class="telegram-btn" href="https://t.me/<?=e($telegramBotUsername)?>?start=login" rel="noopener">Telegram ile giriş yap / kaydol</a><?php else:?><button class="telegram-btn" disabled title="Kayıt botu bağlandığında aktif olacak">Telegram ile giriş yap / kaydol — yakında</button><?php endif?><form method="post"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="login"><input type="hidden" name="next" value="<?=e($_GET['next']??'')?>"><label>Kullanıcı adı veya e-posta<input name="identity" required autocomplete="username"></label><label>Şifre<input type="password" name="password" required autocomplete="current-password"></label><a href="/?page=forgot">Şifremi unuttum</a><button class="btn">Giriş Yap</button></form><p>Hesabın yok mu? <a href="/?page=register">Kayıt ol</a></p><?php elseif($page==='register'):?><h2>Hesabını oluştur</h2><form method="post"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="register"><label>Kullanıcı adı<input name="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_]+" required></label><label>E-posta<input type="email" name="email" required></label><label>Şifre<input type="password" name="password" minlength="10" required></label><small>Kayıt olarak kullanım koşullarını kabul edersiniz.</small><button class="btn">Kayıt Ol</button></form><?php else:?><h2>Şifre sıfırlama</h2><p>Şifre sıfırlama desteği için FORA destek kanalıyla iletişime geçin.</p><a class="btn" href="/?page=login">Girişe Dön</a><?php endif?></div></section>
<?php else:?>
<section class="page-title"><span class="eyebrow">YASAL MERKEZ</span><h1>Politikalar ve tercihler</h1><p>Son güncelleme: 28 Temmuz 2026</p></section><div class="legal-layout"><div class="tabs vertical" data-legal><button class="active" data-target="privacy">Gizlilik Politikası</button><button data-target="terms">Kullanım Koşulları</button><button data-target="cookies">Çerez Politikası</button><button data-target="prefs">Çerez Tercihleri</button></div><article class="legal-copy" id="privacy"><h2>Gizlilik Politikası</h2><p>FORA, hizmetin sunulması için gerekli hesap ve işlem verilerini amaçla sınırlı şekilde işler.</p><h3>Toplanan veriler</h3><p>Hesap bilgileri, güvenlik kayıtları, tercih ve işlem geçmişi.</p><h3>İletişim</h3><p>Yasal başvurular FORA destek kanalı üzerinden iletilebilir.</p></article><article class="legal-copy hidden" id="terms"><h2>Kullanım Koşulları</h2><p>Portal 18 yaş ve üzeri kullanıcılar içindir. Üçüncü taraf tekliflerinde ilgili sponsorun koşulları geçerlidir.</p></article><article class="legal-copy hidden" id="cookies"><h2>Çerez Politikası</h2><p>Zorunlu çerezler oturum ve güvenlik için kullanılır. Analitik ve pazarlama çerezleri kullanıcı tercihlerine göre çalışır.</p></article><article class="legal-copy hidden" id="prefs"><h2>Çerez Tercih Merkezi</h2><label><input type="checkbox" checked disabled> Zorunlu çerezler</label><label><input type="checkbox" id="analyticsCookie"> Analitik çerezler</label><label><input type="checkbox" id="marketingCookie"> Pazarlama çerezleri</label><button class="btn" id="saveCookies">Tercihleri Kaydet</button></article></div>
<?php endif?>
<?php $renderBanners($bannerGroups['bottom']??[],'bottom'); ?>
</main>
<footer class="footer"><div class="footer-brand"><div class="brand"><img src="/assets/brands/optimized/fora-logo-light-sm.png" width="320" height="320" loading="lazy" alt="FORA"></div><p>Tek merkez, sınırsız dijital güç.</p><span>18+ • Sorumlu ve bilinçli kullanım</span></div><div class="footer-follow"><b>Bizi takip et</b><a href="<?=e($telegramBotUsername!==''?'https://t.me/'.$telegramBotUsername:'/?page=chat')?>" rel="noopener">Telegram</a><a href="/?page=chat">FORA Sohbet</a></div><div><b>Genel</b><a href="/">Ana Sayfa</a><a href="/?page=sponsors">Sponsorlar</a><a href="/?page=bonuses">Bonuslar</a></div><div><b>FORA</b><span>FORAGRAMM</span><span>TGM</span><span>foragraph</span><span>Birmilyoncu</span><span>LuckyGramm</span></div><div><b>Yasal</b><a href="/?page=legal">Gizlilik</a><a href="/?page=legal">Koşullar</a><a href="/?page=legal">Çerezler</a></div><small>© <?=date('Y')?> FORA. Tüm hakları saklıdır.</small></footer>
<nav class="mobile-bottom-nav" aria-label="Mobil hızlı menü"><a class="<?=nav_active('home')?>" <?=$page==='home'?'aria-current="page"':''?> href="/"><span>⌂</span>Ana Sayfa</a><a class="<?=nav_active('sponsors')?>" <?=$page==='sponsors'?'aria-current="page"':''?> href="/?page=sponsors"><span>◇</span>Sponsorlar</a><a class="<?=nav_active('bonuses')?>" <?=$page==='bonuses'?'aria-current="page"':''?> href="/?page=bonuses"><span>✦</span>Bonuslar</a><a class="<?=nav_active('chat')?>" <?=$page==='chat'?'aria-current="page"':''?> href="/?page=chat"><span>◉</span>Sohbet</a><a class="<?=nav_active('leaderboard')?>" <?=$page==='leaderboard'?'aria-current="page"':''?> href="/?page=leaderboard"><span>♛</span>Liderlik</a></nav>
<script src="/assets/app.js?v=7" defer></script></body></html>
