# FORA medya ve reklam ölçüleri

Tüm görseller için önerilen format **WebP**, şeffaflık gerekiyorsa **PNG**’dir. Video için **MP4 (H.264)** birinci tercih, **WebM** ikinci tercihtir. Videolar sessiz, döngüye uygun ve en fazla 15 saniye olmalıdır.

| Alan | Masaüstü üretim ölçüsü | Mobil üretim ölçüsü | Oran | Önerilen üst sınır |
|---|---:|---:|---:|---:|
| Üst slider | 1920×320 px | 1080×472 px | 6:1 / 16:7 | görsel 450 KB, video 6 MB |
| Alt slider | 1920×320 px | 1080×472 px | 6:1 / 16:7 | görsel 450 KB, video 6 MB |
| Orta slider | 1600×400 px | 1080×472 px | 4:1 / 16:7 | görsel 450 KB, video 6 MB |
| Sol dikey banner | 300×1200 px | mobilde gösterilmez | 1:4 | görsel 350 KB, video 5 MB |
| Sağ dikey banner | 300×1200 px | mobilde gösterilmez | 1:4 | görsel 350 KB, video 5 MB |
| Bonus kartı | 1200×750 px | aynı dosya | 16:10 | 350 KB |
| Deneme bonusu kartı | 1200×750 px | aynı dosya | 16:10 | 350 KB |
| Sponsor logosu | 600×600 px | aynı dosya | 1:1 | 200 KB |

## Güvenli tasarım alanı

- Üst/orta/alt sliderlarda yazı ve logoları görselin orta yüzde 70’lik bölümünde tutun.
- Dikey bannerlarda ana mesajı orta yüzde 80’lik alanda tutun.
- Bonus görsellerinde başlık, logo ve teklif metni kenarlardan en az 60 px içeride olmalıdır.
- Bağlantı görsele gömülmez; paneldeki **Gömülü bağlantı** alanına yazılır.

## Panel kullanımı

1. Medyayı **Medya Kütüphanesi** bölümüne yükleyin.
2. Oluşan `/uploads/...` adresini kopyalayın.
3. **Slider & Banner** bölümünde konumu ve medya türünü seçin.
4. `media_url` alanına masaüstü dosyasını, varsa `mobile_media_url` alanına mobil dosyayı girin.
5. `link_url`, görünürlük, sıra ve yayın tarihlerini kaydedin.

Yanlardaki dikey reklamlar 1100 px altındaki ekranlarda otomatik gizlenir; mobilde içerik alanını daraltmaz.
