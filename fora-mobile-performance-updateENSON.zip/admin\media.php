<?php
$appRoot=is_dir(dirname(__DIR__).'/app')?dirname(__DIR__):dirname(__DIR__,2);
require $appRoot.'/app/bootstrap.php';
require_admin();
$pdo=db();$flash='';
if(!$pdo){http_response_code(503);exit('Veritabanı bağlantısı yok.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
    check_csrf();
    if(!isset($_FILES['image'])||$_FILES['image']['error']!==UPLOAD_ERR_OK)$flash='Dosya yüklenemedi.';
    else{
        $f=$_FILES['image'];$max=25*1024*1024;
        $fi=new finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name']);
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','video/mp4'=>'mp4','video/webm'=>'webm'];
        $isVideo=str_starts_with($mime,'video/');$info=$isVideo?[null,null]:@getimagesize($f['tmp_name']);
        if($f['size']>$max||!isset($allowed[$mime])||(!$isVideo&&!$info))$flash='Yalnızca 25 MB altı JPEG, PNG, WebP, MP4 veya WebM yükleyin.';
        else{
            $name=bin2hex(random_bytes(18)).'.'.$allowed[$mime];$dir=dirname(__DIR__).'/uploads';
            if(!is_dir($dir))mkdir($dir,0755,true);$dest=$dir.'/'.$name;
            if(!move_uploaded_file($f['tmp_name'],$dest))$flash='Dosya kaydedilemedi.';
            else{
                $url='/uploads/'.$name;
                $q=$pdo->prepare('INSERT INTO media_library(original_name,file_name,public_url,mime_type,width,height,file_size,alt_text,uploaded_by) VALUES(?,?,?,?,?,?,?,?,?)');
                $q->execute([mb_substr(basename($f['name']),0,190),$name,$url,$mime,$info[0],$info[1],$f['size'],trim($_POST['alt_text']??''),(int)$_SESSION['uid']]);
                $flash='Medya kütüphanesine eklendi.';
            }
        }
    }
}
$rows=$pdo->query('SELECT * FROM media_library ORDER BY id DESC LIMIT 100')->fetchAll();
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FORA Medya</title><link rel="stylesheet" href="/assets/app.css?v=6"></head><body class="admin-body"><main class="admin-main">
<div class="page-title"><span class="eyebrow">FORA YÖNETİM</span><h1>Medya Kütüphanesi</h1><p>Görsel: JPEG, PNG, WebP. Video: MP4 veya WebM. En fazla 25 MB.</p></div>
<?php if($flash):?><div class="notice"><?=e($flash)?></div><?php endif?>
<form method="post" enctype="multipart/form-data" class="media-upload"><input type="hidden" name="csrf" value="<?=csrf()?>"><label>Medya dosyası<input type="file" name="image" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" required></label><label>Alternatif metin / medya açıklaması<input name="alt_text" maxlength="190"></label><button class="btn">Yükle</button></form>
<div class="media-grid"><?php foreach($rows as $r):?><article><?php if(str_starts_with($r['mime_type'],'video/')):?><video controls muted preload="metadata" src="<?=e($r['public_url'])?>"></video><?php else:?><img src="<?=e($r['public_url'])?>" alt="<?=e($r['alt_text']??'')?>"><?php endif?><input readonly value="<?=e($r['public_url'])?>" onclick="this.select()"><small><?=e($r['mime_type'])?><?php if($r['width']):?> • <?=intval($r['width'])?>×<?=intval($r['height'])?><?php endif?></small></article><?php endforeach?></div>
<p><a class="ghost" href="/admin/">← Yönetim paneli</a></p></main></body></html>
