document.documentElement.classList.add('js');
const $=(selector,root=document)=>root.querySelector(selector);
const $$=(selector,root=document)=>[...root.querySelectorAll(selector)];
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;

if(!reducedMotion&&'IntersectionObserver'in window){
  const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add('in-view');
      revealObserver.unobserve(entry.target);
    }
  }),{rootMargin:'80px 0px',threshold:.08});
  $$('.reveal').forEach(element=>revealObserver.observe(element));
}else{
  $$('.reveal').forEach(element=>element.classList.add('in-view'));
}

const menuButton=$('.menu-btn');
const closeMenu=()=>{
  document.body.classList.remove('menu-open');
  menuButton?.setAttribute('aria-expanded','false');
};
menuButton?.addEventListener('click',event=>{
  document.body.classList.toggle('menu-open');
  event.currentTarget.setAttribute('aria-expanded',document.body.classList.contains('menu-open'));
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeMenu()});
$('.sidebar')?.addEventListener('click',event=>{if(event.target.closest('a'))closeMenu()});
document.addEventListener('click',event=>{
  if(!document.body.classList.contains('menu-open'))return;
  if(!event.target.closest('.sidebar')&&!event.target.closest('.menu-btn'))closeMenu();
});

$('#sponsorSearch')?.addEventListener('input',event=>{
  let count=0;
  const query=event.target.value.toLocaleLowerCase('tr');
  $$('.sponsor-card').forEach(card=>{
    const visible=card.dataset.search.includes(query);
    card.hidden=!visible;
    if(visible)count++;
  });
  $('#resultCount').textContent=count;
});

$$('[data-legal] button').forEach(button=>button.addEventListener('click',()=>{
  $$('[data-legal] button').forEach(item=>item.classList.remove('active'));
  button.classList.add('active');
  $$('.legal-copy').forEach(item=>item.classList.toggle('hidden',item.id!==button.dataset.target));
}));
$('#saveCookies')?.addEventListener('click',()=>{
  localStorage.setItem('fora_cookie_prefs',JSON.stringify({
    analytics:$('#analyticsCookie').checked,
    marketing:$('#marketingCookie').checked
  }));
  alert('Tercihleriniz bu cihazda kaydedildi.');
});

const chatMessages=$('#chatMessages');
const chatForm=$('#chatForm');
const chatStatus=$('#chatStatus');
let lastChatSignature='';
const escapeHtml=value=>String(value).replace(/[&<>"']/g,char=>({
  '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
}[char]));
const renderChat=messages=>{
  if(!chatMessages)return;
  const signature=messages.map(message=>`${message.id}:${message.created_at}`).join('|');
  if(signature===lastChatSignature)return;
  lastChatSignature=signature;
  chatMessages.innerHTML=messages.map(message=>`<article><b>${escapeHtml(message.username)}</b><p>${escapeHtml(message.message)}</p><small>${message.created_at}${Number(message.coin_awarded)>0?' • +'+Number(message.coin_awarded).toFixed(2)+' FORA Coin':''}</small></article>`).join('');
  chatMessages.scrollTop=chatMessages.scrollHeight;
};
const loadChat=()=>{
  if(document.hidden)return Promise.resolve();
  return fetch('/chat.php',{headers:{Accept:'application/json'}})
    .then(response=>response.json())
    .then(data=>{if(data.ok)renderChat(data.messages)})
    .catch(()=>{});
};
if(chatMessages){
  loadChat();
  setInterval(loadChat,10000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)loadChat()});
}

$$('[data-bonus-filter]').forEach(button=>button.addEventListener('click',()=>{
  $$('[data-bonus-filter]').forEach(item=>item.classList.toggle('active',item===button));
  $$('.bonus-card').forEach(card=>{
    card.hidden=button.dataset.bonusFilter!=='all'&&card.dataset.bonusCategory!==button.dataset.bonusFilter;
  });
}));
const bonusDialog=$('#bonusDialog');
$$('.bonus-detail').forEach(button=>button.addEventListener('click',()=>{
  if(!bonusDialog)return;
  $('h2',bonusDialog).textContent=button.dataset.title||'Bonus Detayı';
  $('.modal-copy',bonusDialog).textContent=button.dataset.content||'';
  const art=$('.modal-art',bonusDialog);
  const image=button.dataset.image;
  art.innerHTML=image?`<img src="${image.replace(/"/g,'&quot;')}" alt="">`:'FORA';
  bonusDialog.showModal();
}));
$('.modal-close',bonusDialog||document)?.addEventListener('click',()=>bonusDialog.close());

$$('[data-slider]').forEach(slider=>{
  const slides=$$('.site-banner',slider);
  if(!slides.length)return;
  let current=0;
  const activate=index=>slides.forEach((slide,position)=>{
    const active=position===index;
    slide.classList.toggle('active',active);
    const video=$('video',slide);
    if(!video)return;
    if(active){
      if(!video.src&&video.dataset.src)video.src=video.dataset.src;
      if(!reducedMotion&&!document.hidden)video.play().catch(()=>{});
    }else video.pause();
  });
  activate(0);
  if(slides.length>1&&!reducedMotion)setInterval(()=>{
    if(document.hidden)return;
    current=(current+1)%slides.length;
    activate(current);
  },6000);
});

chatForm?.addEventListener('submit',async event=>{
  event.preventDefault();
  const button=chatForm.querySelector('button');
  button.disabled=true;
  try{
    const response=await fetch('/chat.php',{method:'POST',body:new FormData(chatForm),headers:{Accept:'application/json'}});
    const data=await response.json();
    chatStatus.textContent=data.ok
      ?(Number(data.coin_awarded)>0?`+${Number(data.coin_awarded).toFixed(2)} FORA Coin kazandınız.`:'Mesaj gönderildi. Tekrar ve hız kuralları uygulandı.')
      :data.error;
    if(data.ok){chatForm.reset();lastChatSignature='';loadChat()}
  }catch{
    chatStatus.textContent='Mesaj gönderilemedi.';
  }finally{
    button.disabled=false;
  }
});
