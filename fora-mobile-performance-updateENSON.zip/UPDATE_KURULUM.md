# FORA mobil arayüz ve performans güncellemesi

Bu paket yalnız public arayüz, yönetim paneli, optimize marka görselleri ve eklemeli SQL migrasyonlarını içerir. `app/config.php` içermez.

## Uygulama sırası

1. Mevcut canlı dosyaların ve veritabanının yedeğini alın.
2. phpMyAdmin üzerinde `database/admin-media-layout.sql` dosyasını çalıştırın.
3. Ardından `database/bonus-sponsor-editor.sql` dosyasını çalıştırın.
4. ZIP içeriğini `public_html` içine çıkarıp mevcut `index.php`, `admin/` ve `assets/` dosyalarının üzerine yazın.
5. Tarayıcı önbelleğini temizleyip ana sayfa, Sponsorlar, Bonuslar, Sohbet, Liderlik ve yönetim panelini kontrol edin.

## Performans değişiklikleri

- Ana sayfada kullanılan marka görselleri yaklaşık 13,68 MB’den 1,57 MB’ye düşürüldü.
- Alt bölüm görsellerine lazy loading ve async decoding eklendi.
- Google Fonts dış isteği kaldırıldı.
- Sohbet yenilemesi sekme görünür değilken durur ve veri değişmediyse DOM tekrar çizilmez.
- Slider videoları yalnız aktif olduklarında yüklenir ve oynatılır.
- Animasyonlar yalnız `transform` ve `opacity` kullanır; hareket azaltma tercihi desteklenir.

Canlı `app/config.php`, sponsor kayıtları, trafik kayıtları, kullanıcılar ve FORA Coin verileri değiştirilmez.
